package com.dheeraj.userapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dheeraj.userapp.beans.UserBean;
import com.dheeraj.userapp.dao.UserDao;
import com.dheeraj.userapp.dao.impl.UserDaoImpl;

@SuppressWarnings("serial")
public class SignUpServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		UserBean userBean = new UserBean();
		UserDao userDaoImpl = new UserDaoImpl();

		userBean.setUsername(req.getParameter("username"));
		userBean.setUpassword(req.getParameter("upassword"));
		userBean.setFname(req.getParameter("firstname"));
		userBean.setLastname(req.getParameter("lastname"));
		userBean.setGender(req.getParameter("gender"));
		userBean.setAddress(req.getParameter("address"));
		userBean.setEmail(req.getParameter("email"));
		userBean.setPhonenum(Long.parseLong(req.getParameter("phonenumber")));

		int row = userDaoImpl.createUser(userBean);

		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		if (row > 0) {
			pw.print("User Created Succes fully");

		} else {
			pw.print("Error occured while creating user");
		}
	}
}
