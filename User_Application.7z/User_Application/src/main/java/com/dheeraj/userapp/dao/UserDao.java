package com.dheeraj.userapp.dao;

import com.dheeraj.userapp.beans.UserBean;

public interface UserDao {

	int createUser(UserBean ubean);

	UserBean fetchUser(UserBean ubean);

	UserBean updateUser(UserBean ubean);

	int deletUser(UserBean ubean);

}
