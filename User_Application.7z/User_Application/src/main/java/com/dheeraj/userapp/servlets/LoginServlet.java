package com.dheeraj.userapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dheeraj.userapp.beans.UserBean;
import com.dheeraj.userapp.dao.UserDao;
import com.dheeraj.userapp.dao.impl.UserDaoImpl;

@SuppressWarnings("serial")
//@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	private UserDao userDaoImpl;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		userDaoImpl = new UserDaoImpl();
		UserBean ub = new UserBean();

		ub.setUsername(req.getParameter("username"));
		ub.setUpassword(req.getParameter("password"));

		UserBean resultBean = userDaoImpl.fetchUser(ub);
		resp.setContentType("text/html");
		PrintWriter pw = resp.getWriter();
		if (null != resultBean) {
			pw.println("====USER Login Details======");
			pw.println("<br>" + "Welcome " + resultBean.getFname() + " " + resultBean.getLastname() + "</br>");
		} else {
			pw.println("====USER Login failed ======");
			RequestDispatcher rd = req.getRequestDispatcher("/");
			rd.include(req, resp);
		}

	}

}
