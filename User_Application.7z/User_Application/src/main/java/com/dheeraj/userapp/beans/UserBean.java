package com.dheeraj.userapp.beans;

import java.io.Serializable;
import java.sql.Timestamp;

@SuppressWarnings("serial")
public class UserBean implements Serializable {

	private int userid;
	private String username;
	private String upassword;
	private String fname;
	private String lastname;
	private String gender;
	private long phonenum;
	private String address;
	private String email;
	private Timestamp create_ts;
	private Timestamp update_ts;
	private String created_by;
	private String updated_by;

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUpassword() {
		return upassword;
	}

	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public long getPhonenum() {
		return phonenum;
	}

	public void setPhonenum(long phonenum) {
		this.phonenum = phonenum;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Timestamp getCreate_ts() {
		return create_ts;
	}

	public void setCreate_ts(Timestamp create_ts) {
		this.create_ts = create_ts;
	}

	public Timestamp getUpdate_ts() {
		return update_ts;
	}

	public void setUpdate_ts(Timestamp update_ts) {
		this.update_ts = update_ts;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

}
